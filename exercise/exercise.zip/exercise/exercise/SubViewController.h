//
//  SubViewController.h
//  exercise
//
//  Created by Happigo on 14-10-15.
//  Copyright (c) 2014年 HappiVision. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubViewController : UIViewController

@end
